import { GoogleGenAI } from "@google/genai";
import { FormData, Language, PolicyType } from "../types";

const getSystemInstruction = (language: Language) => {
  switch (language) {
    case Language.FRENCH:
      return "Vous êtes un expert juridique spécialisé dans le droit numérique international (RGPD, CCPA, etc.). Générez des documents juridiques professionnels, complets et bien formatés en Markdown.";
    case Language.RUSSIAN:
      return "Вы юридический эксперт, специализирующийся на международном цифровом праве (GDPR, CCPA и т. д.). Создавайте профессиональные, полные и хорошо отформатированные юридические документы в формате Markdown.";
    default:
      return "You are a legal expert specializing in international digital law (GDPR, CCPA, etc.). Generate professional, comprehensive, and well-formatted legal documents in Markdown.";
  }
};

export const generatePolicyContent = async (
  policyType: PolicyType,
  formData: FormData,
  language: Language
): Promise<string> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  const prompt = `
    Create a comprehensive "${policyType}" document.
    
    Target Audience Language: ${language}
    
    Details of the Entity:
    - Company/Site Name: ${formData.companyName}
    - Website URL: ${formData.websiteUrl}
    - Platform Type: ${formData.platformType}
    - Contact Email: ${formData.contactEmail}
    - Country of Jurisdiction: ${formData.country}
    - Physical Address: ${formData.address}
    - Effective Date: ${formData.effectiveDate}

    Requirements:
    1. Use professional legal terminology appropriate for the ${language} language.
    2. Format using clear Markdown headers (#, ##, ###), lists, and bold text.
    3. Include standard clauses relevant to ${policyType} (e.g., data collection, user rights, governing law).
    4. If it is a Privacy Policy, mention GDPR and CCPA compliance if applicable generally.
    5. Do not include placeholders like "[Insert Date]" - use the data provided.
    6. Return ONLY the document content in Markdown.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        systemInstruction: getSystemInstruction(language),
        temperature: 0.3, // Low temperature for more consistent/formal output
      },
    });

    return response.text || "Error generating content. Please try again.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};