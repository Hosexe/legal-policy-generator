import React from 'react';
import { Language, SUPPORTED_LANGUAGES } from '../types';

interface LanguageSwitcherProps {
  selectedLang: Language;
  onSelect: (lang: Language) => void;
}

export const LanguageSwitcher: React.FC<LanguageSwitcherProps> = ({ selectedLang, onSelect }) => {
  return (
    <div className="flex space-x-2 bg-gray-800 p-1 rounded-lg border border-gray-700">
      {SUPPORTED_LANGUAGES.map((lang) => (
        <button
          key={lang.code}
          onClick={() => onSelect(lang.code)}
          className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
            selectedLang === lang.code
              ? 'bg-gray-600 text-white shadow-sm'
              : 'text-gray-400 hover:text-white hover:bg-gray-700'
          }`}
        >
          <span className="mr-1">{lang.flag}</span>
          <span className="hidden sm:inline">{lang.label}</span>
        </button>
      ))}
    </div>
  );
};