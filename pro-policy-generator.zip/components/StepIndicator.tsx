import React from 'react';

interface StepIndicatorProps {
  currentStep: number;
  totalSteps: number;
}

export const StepIndicator: React.FC<StepIndicatorProps> = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex items-center justify-center space-x-2 mb-8">
      {Array.from({ length: totalSteps }).map((_, idx) => (
        <div
          key={idx}
          className={`h-2 rounded-full transition-all duration-300 ${
            idx + 1 === currentStep ? 'w-8 bg-green-500' : 'w-2 bg-gray-600'
          } ${idx + 1 < currentStep ? 'bg-green-700' : ''}`}
        />
      ))}
    </div>
  );
};